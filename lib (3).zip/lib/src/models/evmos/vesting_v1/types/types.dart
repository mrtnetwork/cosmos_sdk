import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

class EvmosVestingV1Types extends TypeUrl {
  static const String basePath = "/evmos.vesting.v1";
  const EvmosVestingV1Types._(super.typeUrl);
  static const EvmosVestingV1Types period =
      EvmosVestingV1Types._("/evmos.vesting.v1.Period");
}
