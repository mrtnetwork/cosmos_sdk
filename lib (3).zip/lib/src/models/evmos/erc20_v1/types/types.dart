import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

class EvmosErc20V1Types extends TypeUrl {
  static const String basePath = "/evmos.erc20.v1";
  const EvmosErc20V1Types._(super.typeUrl, {super.aminoType});
  static const EvmosErc20V1Types msgConvertERC20 = EvmosErc20V1Types._(
      "/evmos.erc20.v1.MsgConvertERC20",
      aminoType: "evmos/MsgConvertERC20");
  static const EvmosErc20V1Types msgConvertCoin = EvmosErc20V1Types._(
      "/evmos.erc20.v1.MsgConvertCoin",
      aminoType: "evmos/MsgConvertCoin");
  static const EvmosErc20V1Types msgUpdateParams = EvmosErc20V1Types._(
      "/evmos.erc20.v1.MsgUpdateParams",
      aminoType: "evmos/erc20/MsgUpdateParams");
  static const EvmosErc20V1Types msgRegisterERC20 = EvmosErc20V1Types._(
      "/evmos.erc20.v1.MsgRegisterERC20",
      aminoType: "evmos/MsgRegisterERC20");
  static const EvmosErc20V1Types msgToggleConversion = EvmosErc20V1Types._(
      "/evmos.erc20.v1.MsgToggleConversion",
      aminoType: "evmos/MsgToggleConversion");

  static const EvmosErc20V1Types msgConvertCoinResponse =
      EvmosErc20V1Types._("/evmos.erc20.v1.MsgConvertCoinResponse");
  static const EvmosErc20V1Types msgConvertERC20Response =
      EvmosErc20V1Types._("/evmos.erc20.v1.MsgConvertERC20Response");
  static const EvmosErc20V1Types msgUpdateParamsResponse =
      EvmosErc20V1Types._("/evmos.erc20.v1.MsgUpdateParamsResponse");
  static const EvmosErc20V1Types params =
      EvmosErc20V1Types._("/evmos.erc20.v1.Params");
  static const EvmosErc20V1Types msgRegisterERC20Response =
      EvmosErc20V1Types._("/evmos.erc20.v1.MsgRegisterERC20Response");
  static const EvmosErc20V1Types msgToggleConversionResponse =
      EvmosErc20V1Types._("/evmos.erc20.v1.MsgToggleConversionResponse");
}
