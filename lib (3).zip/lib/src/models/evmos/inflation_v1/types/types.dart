import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

class EvmosInflationV1Types extends TypeUrl {
  static const String basePath = "/evmos.erc20.v1";
  const EvmosInflationV1Types._(super.typeUrl, {super.aminoType});

  static const EvmosInflationV1Types msgUpdateParams = EvmosInflationV1Types._(
      "/evmos.inflation.v1.MsgUpdateParams",
      aminoType: "evmos/inflation/MsgUpdateParams");

  static const EvmosInflationV1Types exponentialCalculation =
      EvmosInflationV1Types._("/evmos.inflation.v1.ExponentialCalculation");
  static const EvmosInflationV1Types inflationDistribution =
      EvmosInflationV1Types._("/evmos.inflation.v1.InflationDistribution");
  static const EvmosInflationV1Types params =
      EvmosInflationV1Types._("/evmos.inflation.v1.Params");
  static const EvmosInflationV1Types msgUpdateParamsResponse =
      EvmosInflationV1Types._("/evmos.inflation.v1.MsgUpdateParamsResponse");
}
