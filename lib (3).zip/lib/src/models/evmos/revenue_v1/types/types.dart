import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

class EvmosRevenueV1Types extends TypeUrl {
  static const String basePath = "/evmos.revenue.v1";
  const EvmosRevenueV1Types._(super.typeUrl, {super.aminoType});

  static const EvmosRevenueV1Types msgRegisterRevenue = EvmosRevenueV1Types._(
      "/evmos.revenue.v1.MsgRegisterRevenue",
      aminoType: "evmos/MsgRegisterRevenue");
  static const EvmosRevenueV1Types msgUpdateRevenue = EvmosRevenueV1Types._(
      "/evmos.revenue.v1.MsgUpdateRevenue",
      aminoType: "evmos/MsgUpdateRevenue");
  static const EvmosRevenueV1Types msgCancelRevenue = EvmosRevenueV1Types._(
      "/evmos.revenue.v1.MsgCancelRevenue",
      aminoType: "evmos/MsgCancelRevenue");
  static const EvmosRevenueV1Types msgUpdateParams = EvmosRevenueV1Types._(
      "/evmos.revenue.v1.MsgUpdateParams",
      aminoType: "evmos/MsgUpdateParams");

  static const EvmosRevenueV1Types msgRegisterRevenueResponse =
      EvmosRevenueV1Types._("/evmos.revenue.v1.MsgRegisterRevenueResponse");
  static const EvmosRevenueV1Types msgUpdateRevenueResponse =
      EvmosRevenueV1Types._("/evmos.revenue.v1.MsgUpdateRevenueResponse");
  static const EvmosRevenueV1Types msgCancelRevenueResponse =
      EvmosRevenueV1Types._("/evmos.revenue.v1.MsgCancelRevenueResponse");
  static const EvmosRevenueV1Types params =
      EvmosRevenueV1Types._("/evmos.revenue.v1.Params");
  static const EvmosRevenueV1Types msgUpdateParamsResponse =
      EvmosRevenueV1Types._("/evmos.revenue.v1.MsgUpdateParamsResponse");
}
