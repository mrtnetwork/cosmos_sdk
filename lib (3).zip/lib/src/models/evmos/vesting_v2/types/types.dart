import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

class EvmosVestingV2Types extends TypeUrl {
  static const String basePath = "/evmos.revenue.v1";
  const EvmosVestingV2Types._(super.typeUrl, {super.aminoType});

  static const EvmosVestingV2Types msgCreateClawbackVestingAccount =
      EvmosVestingV2Types._("/evmos.vesting.v2.MsgCreateClawbackVestingAccount",
          aminoType: "evmos/MsgCreateClawbackVestingAccount");
  static const EvmosVestingV2Types msgFundVestingAccount =
      EvmosVestingV2Types._("/evmos.vesting.v2.MsgFundVestingAccount",
          aminoType: "evmos/MsgFundVestingAccount");
  static const EvmosVestingV2Types msgClawback = EvmosVestingV2Types._(
      "/evmos.vesting.v2.MsgClawback",
      aminoType: "evmos/MsgClawback");
  static const EvmosVestingV2Types msgUpdateVestingFunder =
      EvmosVestingV2Types._("/evmos.vesting.v2.MsgUpdateVestingFunder",
          aminoType: "evmos/MsgUpdateVestingFunder");
  static const EvmosVestingV2Types msgConvertVestingAccount =
      EvmosVestingV2Types._("/evmos.vesting.v2.MsgConvertVestingAccount",
          aminoType: "evmos/MsgConvertVestingAccount");

  static const EvmosVestingV2Types msgCreateClawbackVestingAccountResponse =
      EvmosVestingV2Types._(
          "/evmos.vesting.v2.MsgCreateClawbackVestingAccountResponse");
  static const EvmosVestingV2Types msgFundVestingAccountResponse =
      EvmosVestingV2Types._("/evmos.vesting.v2.MsgFundVestingAccountResponse");
  static const EvmosVestingV2Types msgClawbackResponse =
      EvmosVestingV2Types._("/evmos.vesting.v2.MsgClawbackResponse");
  static const EvmosVestingV2Types msgUpdateVestingFunderResponse =
      EvmosVestingV2Types._("/evmos.vesting.v2.MsgUpdateVestingFunderResponse");
  static const EvmosVestingV2Types msgConvertVestingAccountResponse =
      EvmosVestingV2Types._(
          "/evmos.vesting.v2.MsgConvertVestingAccountResponse");
}
