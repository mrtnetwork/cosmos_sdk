import 'package:cosmos_sdk/src/exception/exception.dart';
import 'package:cosmos_sdk/src/models/ethermint/evm_v1/service/msg_ethereum_tx.dart';
import 'package:cosmos_sdk/src/models/ethermint/evm_v1/service/msg_ethereum_tx_response.dart';
import 'package:cosmos_sdk/src/models/ethermint/evm_v1/service/msg_update_param.dart';
import 'package:cosmos_sdk/src/models/ethermint/evm_v1/types/types.dart';
import 'package:cosmos_sdk/src/models/ethermint/service/service.dart';
import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

abstract class EvmV1Service<T extends CosmosMessage>
    extends EthermintService<T> {
  const EvmV1Service();
  static const String root = "/ethermint.evm.v1";

  static T? fromJson<T extends EvmV1Service>(
      {required String typeUrl, required Map<String, dynamic> json}) {
    final type = EvmV1Types.findService(typeUrl);
    final EvmV1Service? service = switch (type) {
      EvmV1Types.msgEthereumTxResponse => MsgEthereumTxResponse.fromJson(json),
      EvmV1Types.msgEthereumTx => MsgEthereumTx.fromJson(json),
      EvmV1Types.msgUpdateParams => EVMV1MsgUpdateParams.fromJson(json),
      _ => null
    } as EvmV1Service?;

    if (service == null) return null;
    if (service is! T) {
      throw DartCosmosSdkPluginException("Invalid Ethermint Service.",
          details: {
            "excepted": "$T",
            "service": service.runtimeType.toString()
          });
    }
    return service;
  }

  static T? deserialize<T extends ServiceMessage>(
      {required String typeUrl, required List<int> bytes}) {
    final type = EvmV1Types.findService(typeUrl);
    final ServiceMessage? service = switch (type) {
      EvmV1Types.msgEthereumTxResponse =>
        MsgEthereumTxResponse.deserialize(bytes),
      EvmV1Types.msgEthereumTx => MsgEthereumTx.deserialize(bytes),
      EvmV1Types.msgUpdateParams => EVMV1MsgUpdateParams.deserialize(bytes),
      _ => null
    } as ServiceMessage?;

    if (service == null) return null;
    if (service is! T) {
      throw DartCosmosSdkPluginException("Invalid Ethermint Service.",
          details: {
            "excepted": "$T",
            "service": service.runtimeType.toString()
          });
    }
    return service;
  }
}
