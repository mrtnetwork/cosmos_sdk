import 'package:cosmos_sdk/src/models/ethermint/evm_v1/core/service.dart';
import 'package:cosmos_sdk/src/models/ethermint/fee_market_v1/core/service.dart';
import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';
import 'package:cosmos_sdk/src/utils/utils.dart';

abstract class EthermintService<T extends CosmosMessage>
    extends ServiceMessage<T> {
  const EthermintService();
  static const String root = "/ethermint";
  static T? fromJson<T extends EthermintService>(
      {required String typeUrl, required Map<String, dynamic> json}) {
    final String root = CosmosUtils.extractServiceRoot(typeUrl);
    return switch (root) {
      EvmV1Service.root => EvmV1Service.fromJson(typeUrl: typeUrl, json: json),
      FeeMarketService.root =>
        FeeMarketService.fromJson(typeUrl: typeUrl, json: json),
      _ => null
    };
  }

  static T? deserialize<T extends EthermintService>(
      {required String typeUrl, required List<int> bytes}) {
    final String root = CosmosUtils.extractServiceRoot(typeUrl);
    return switch (root) {
      EvmV1Service.root =>
        EvmV1Service.deserialize(typeUrl: typeUrl, bytes: bytes),
      FeeMarketService.root =>
        FeeMarketService.deserialize(typeUrl: typeUrl, bytes: bytes),
      _ => null
    };
  }
}
