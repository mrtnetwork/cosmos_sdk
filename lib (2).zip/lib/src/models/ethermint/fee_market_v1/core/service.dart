import 'package:cosmos_sdk/src/exception/exception.dart';
import 'package:cosmos_sdk/src/models/ethermint/fee_market_v1/fee_market_v1.dart';
import 'package:cosmos_sdk/src/models/ethermint/service/service.dart';
import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

abstract class FeeMarketService<T extends CosmosMessage>
    extends EthermintService<T> {
  const FeeMarketService();
  @override
  FeeMarketTypes get service;
  static const String root = "/ethermint.feemarket.v1";
  static T? fromJson<T extends FeeMarketService>(
      {required String typeUrl, required Map<String, dynamic> json}) {
    final type = FeeMarketTypes.findService(typeUrl);
    final FeeMarketService? service = switch (type) {
      FeeMarketTypes.updateParams => FeeMarketV1MsgUpdateParams.fromJson(json),
      _ => null
    } as FeeMarketService?;
    if (service == null) return null;
    if (service is! T) {
      throw DartCosmosSdkPluginException("Invalid Ethermint Service.",
          details: {
            "excepted": "$T",
            "service": service.runtimeType.toString()
          });
    }
    return service;
  }

  static T? deserialize<T extends FeeMarketService>(
      {required String typeUrl, required List<int> bytes}) {
    final type = FeeMarketTypes.findService(typeUrl);
    final FeeMarketService? service = switch (type) {
      FeeMarketTypes.updateParams =>
        FeeMarketV1MsgUpdateParams.deserialize(bytes),
      _ => null
    } as FeeMarketService?;
    if (service == null) return null;
    if (service is! T) {
      throw DartCosmosSdkPluginException("Invalid Ethermint Service.",
          details: {
            "excepted": "$T",
            "service": service.runtimeType.toString()
          });
    }
    return service;
  }
}
