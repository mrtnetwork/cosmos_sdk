import 'package:cosmos_sdk/src/exception/exception.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_applications_fee_v1/service/msg_pay_packet_fee.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_applications_fee_v1/service/msg_pay_packet_fee_async.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_applications_fee_v1/service/msg_register_counterparty_payee.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_applications_fee_v1/service/msg_register_payee.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_applications_interchain_accounts_controller_v1/service/msg_send_tx.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_applications_interchain_accounts_controller_v1/service/msg_update_params.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_applications_interchain_accounts_host_v1/service/module_query_safe.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_applications_interchain_accounts_host_v1/service/msg_update_params.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_acknowledgement.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_close_confirm.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_close_init.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_open_ack.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_open_confirm.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_open_init.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_open_try.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_upgrade_ack.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_upgrade_cancel.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_upgrade_confirm.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_upgrade_init.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_upgrade_open.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_upgrade_timeout.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_channel_upgrade_try.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_prune_acknowledgements.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_recv_packet.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_timeout.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_timeout_on_close.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v1/service/msg_update_params.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v2/service/acknowledgement.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v2/service/recv_packet.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_channel_v2/service/send_packet.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_client_v1/service/msg_create_client.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_client_v1/service/msg_ibc_software_upgrade.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_client_v1/service/msg_recover_client.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_client_v1/service/msg_update_client.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_client_v1/service/msg_update_params.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_client_v1/service/msg_upgrade_client.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_client_v2/service/register_counterparty.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_connection_v1/service/msg_connection_open_ack.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_connection_v1/service/msg_connection_open_confirm.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_connection_v1/service/msg_connection_open_init.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_connection_v1/service/msg_connection_open_try.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_connection_v1/service/msg_update_params.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_lightclients_wasm_v1/service/msg_migrate_ontract.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_lightclients_wasm_v1/service/msg_remove_checksum.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_lightclients_wasm_v1/service/msg_store_code.dart';
import 'package:cosmos_sdk/src/models/ibc/types/types.dart';
import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

import '../ibc_applications_interchain_accounts_controller_v1/service/msg_register_interchain_account.dart';
import '../ibc_applications_transfer_v1/service/msg_transfer.dart';
import '../ibc_applications_transfer_v1/service/msg_update_params.dart';
import '../ibc_core_channel_v2/service/timeout.dart';

abstract class IbcService<T extends CosmosMessage> extends ServiceMessage<T> {
  const IbcService();
  static const String root = "/ibc";
  @override
  IbcTypes get service;
  static T? fromJson<T extends IbcService>(
      {required String typeUrl, required Map<String, dynamic> json}) {
    final type = IbcTypes.findService(typeUrl);
    final IbcService? service = switch (type) {
      IbcTypes.payPacketFeeAsync => MsgPayPacketFeeAsync.fromJson(json),
      IbcTypes.payPacketFee => MsgPayPacketFee.fromJson(json),
      IbcTypes.registerCounterpartyPayee =>
        MsgRegisterCounterpartyPayee.fromJson(json),
      IbcTypes.registerPayee => MsgRegisterPayee.fromJson(json),
      //
      IbcTypes.registerInterchainAccount =>
        MsgRegisterInterchainAccount.fromJson(json),
      IbcTypes.serviceMsgSendTx => MsgSendTx.fromJson(json),
      IbcTypes.interchainAccountsControllerUpdateParams =>
        InterchainAccountsControllerMsgUpdateParams.fromJson(json),

      ///
      IbcTypes.interchainAccountsHostModuleQuerySafe =>
        InterchainAccountsHostModuleQuerySafe.fromJson(json),
      IbcTypes.interchainAccountsHostUpdateParams =>
        InterchainAccountsHostUpdateParams.fromJson(json),

      ///
      IbcTypes.transfer => MsgTransfer.fromJson(json),
      IbcTypes.ibcTransferUpdateParams =>
        IbcTransferMsgUpdateParams.fromJson(json),

      ///
      IbcTypes.acknowledgement => MsgAcknowledgement.fromJson(json),
      IbcTypes.channelCloseConfirm => MsgChannelCloseConfirm.fromJson(json),
      IbcTypes.channelCloseInit => MsgChannelCloseInit.fromJson(json),
      IbcTypes.channelOpenAck => MsgChannelOpenAck.fromJson(json),
      IbcTypes.channelOpenConfirm => MsgChannelOpenConfirm.fromJson(json),
      IbcTypes.channelOpenInit => MsgChannelOpenInit.fromJson(json),
      IbcTypes.channelOpenTry => MsgChannelOpenTry.fromJson(json),
      IbcTypes.channelUpgradeAck => MsgChannelUpgradeAck.fromJson(json),
      IbcTypes.channelUpgradeCancel => MsgChannelUpgradeCancel.fromJson(json),
      IbcTypes.channelUpgradeConfirm => MsgChannelUpgradeConfirm.fromJson(json),
      IbcTypes.channelUpgradeInit => MsgChannelUpgradeInit.fromJson(json),
      IbcTypes.channelUpgradeOpen => MsgChannelUpgradeOpen.fromJson(json),
      IbcTypes.channelUpgradeTimeout => MsgChannelUpgradeTimeout.fromJson(json),
      IbcTypes.channelUpgradeTry => MsgChannelUpgradeTry.fromJson(json),
      IbcTypes.pruneAcknowledgements => MsgPruneAcknowledgements.fromJson(json),
      IbcTypes.recvPacket => MsgRecvPacket.fromJson(json),
      IbcTypes.timeoutOnClose => MsgTimeoutOnClose.fromJson(json),
      IbcTypes.serviceTimeout => MsgTimeout.fromJson(json),
      IbcTypes.updateChannelParams => IbcChannelMsgUpdateParams.fromJson(json),
      IbcTypes.channelV2MsgAcknowledgementService =>
        IbcChannelV2MsgAcknowledgement.fromJson(json),
      IbcTypes.channelV2MsgRecvPacketService =>
        IbcChannelV2MsgRecvPacket.fromJson(json),
      IbcTypes.channelV2MsgSendPacketService =>
        IbcChannelV2MsgSendPacket.fromJson(json),
      IbcTypes.channelV2MsgTimeoutService =>
        IbcChannelV2MsgTimeout.fromJson(json),
      IbcTypes.createClient => MsgCreateClient.fromJson(json),
      IbcTypes.iBCSoftwareUpgrade => MsgIBCSoftwareUpgrade.fromJson(json),
      IbcTypes.recoverClient => MsgRecoverClient.fromJson(json),
      IbcTypes.updateClient => MsgUpdateClient.fromJson(json),
      IbcTypes.updateClientParams => IbcClientMsgUpdateParams.fromJson(json),
      IbcTypes.upgradeClient => MsgUpgradeClient.fromJson(json),
      IbcTypes.ibClientV2MsgRegisterCounterpartyService =>
        IbcClientV2MsgRegisterCounterparty.fromJson(json),
      IbcTypes.ibcConnectionConnectionOpenAck =>
        IbcConnectionMsgConnectionOpenAck.fromJson(json),
      IbcTypes.ibcConnectionConnectionOpenConfirm =>
        IbcConnectionMsgConnectionOpenConfirm.fromJson(json),
      IbcTypes.ibcConnectionConnectionOpenInit =>
        IbcConnectionMsgConnectionOpenInit.fromJson(json),
      IbcTypes.ibcConnectionConnectionOpenTry =>
        IbcConnectionMsgConnectionOpenTry.fromJson(json),
      IbcTypes.ibcConnectionUpdateConnectionParams =>
        IbcConnectionMsgUpdateParams.fromJson(json),
      IbcTypes.ibcLightClientsWasmMigrateContract =>
        IbcLightClientsWasmMsgMigrateContract.fromJson(json),
      IbcTypes.ibcLightClientsWasmRemoveChecksum =>
        IbcLightClientsWasmMsgRemoveChecksum.fromJson(json),
      IbcTypes.ibcLightClientsWasmStoreCode =>
        IbcLightClientsWasmMsgStoreCode.fromJson(json),
      _ => null
    } as IbcService?;
    print("service ${service.runtimeType}");
    if (service == null) return null;
    if (service is! T) {
      throw DartCosmosSdkPluginException("Invalid IBC Service.", details: {
        "excepted": "$T",
        "service": service.runtimeType.toString()
      });
    }
    return service;
  }

  static T? deserialize<T extends ServiceMessage>(
      {required String typeUrl, required List<int> bytes}) {
    final type = IbcTypes.findService(typeUrl);
    print("come here $type");
    final ServiceMessage? service = switch (type) {
      IbcTypes.payPacketFeeAsync => MsgPayPacketFeeAsync.deserialize(bytes),
      IbcTypes.payPacketFee => MsgPayPacketFee.deserialize(bytes),
      IbcTypes.registerCounterpartyPayee =>
        MsgRegisterCounterpartyPayee.deserialize(bytes),
      IbcTypes.registerPayee => MsgRegisterPayee.deserialize(bytes),
      //
      IbcTypes.registerInterchainAccount =>
        MsgRegisterInterchainAccount.deserialize(bytes),
      IbcTypes.serviceMsgSendTx => MsgSendTx.deserialize(bytes),
      IbcTypes.interchainAccountsControllerUpdateParams =>
        InterchainAccountsControllerMsgUpdateParams.deserialize(bytes),

      ///
      IbcTypes.interchainAccountsHostModuleQuerySafe =>
        InterchainAccountsHostModuleQuerySafe.deserialize(bytes),
      IbcTypes.interchainAccountsHostUpdateParams =>
        InterchainAccountsHostUpdateParams.deserialize(bytes),

      ///
      IbcTypes.transfer => MsgTransfer.deserialize(bytes),
      IbcTypes.ibcTransferUpdateParams =>
        IbcTransferMsgUpdateParams.deserialize(bytes),

      ///
      IbcTypes.acknowledgement => MsgAcknowledgement.deserialize(bytes),
      IbcTypes.channelCloseConfirm => MsgChannelCloseConfirm.deserialize(bytes),
      IbcTypes.channelCloseInit => MsgChannelCloseInit.deserialize(bytes),
      IbcTypes.channelOpenAck => MsgChannelOpenAck.deserialize(bytes),
      IbcTypes.channelOpenConfirm => MsgChannelOpenConfirm.deserialize(bytes),
      IbcTypes.channelOpenInit => MsgChannelOpenInit.deserialize(bytes),
      IbcTypes.channelOpenTry => MsgChannelOpenTry.deserialize(bytes),
      IbcTypes.channelUpgradeAck => MsgChannelUpgradeAck.deserialize(bytes),
      IbcTypes.channelUpgradeCancel =>
        MsgChannelUpgradeCancel.deserialize(bytes),
      IbcTypes.channelUpgradeConfirm =>
        MsgChannelUpgradeConfirm.deserialize(bytes),
      IbcTypes.channelUpgradeInit => MsgChannelUpgradeInit.deserialize(bytes),
      IbcTypes.channelUpgradeOpen => MsgChannelUpgradeOpen.deserialize(bytes),
      IbcTypes.channelUpgradeTimeout =>
        MsgChannelUpgradeTimeout.deserialize(bytes),
      IbcTypes.channelUpgradeTry => MsgChannelUpgradeTry.deserialize(bytes),
      IbcTypes.pruneAcknowledgements =>
        MsgPruneAcknowledgements.deserialize(bytes),
      IbcTypes.recvPacket => MsgRecvPacket.deserialize(bytes),
      IbcTypes.timeoutOnClose => MsgTimeoutOnClose.deserialize(bytes),
      IbcTypes.serviceTimeout => MsgTimeout.deserialize(bytes),
      IbcTypes.updateChannelParams =>
        IbcChannelMsgUpdateParams.deserialize(bytes),
      IbcTypes.channelV2MsgAcknowledgementService =>
        IbcChannelV2MsgAcknowledgement.deserialize(bytes),
      IbcTypes.channelV2MsgRecvPacketService =>
        IbcChannelV2MsgRecvPacket.deserialize(bytes),
      IbcTypes.channelV2MsgSendPacketService =>
        IbcChannelV2MsgSendPacket.deserialize(bytes),
      IbcTypes.channelV2MsgTimeoutService =>
        IbcChannelV2MsgTimeout.deserialize(bytes),
      IbcTypes.createClient => MsgCreateClient.deserialize(bytes),
      IbcTypes.iBCSoftwareUpgrade => MsgIBCSoftwareUpgrade.deserialize(bytes),
      IbcTypes.recoverClient => MsgRecoverClient.deserialize(bytes),
      IbcTypes.updateClient => MsgUpdateClient.deserialize(bytes),
      IbcTypes.updateClientParams =>
        IbcClientMsgUpdateParams.deserialize(bytes),
      IbcTypes.upgradeClient => MsgUpgradeClient.deserialize(bytes),
      IbcTypes.ibClientV2MsgRegisterCounterpartyService =>
        IbcClientV2MsgRegisterCounterparty.deserialize(bytes),
      IbcTypes.ibcConnectionConnectionOpenAck =>
        IbcConnectionMsgConnectionOpenAck.deserialize(bytes),
      IbcTypes.ibcConnectionConnectionOpenConfirm =>
        IbcConnectionMsgConnectionOpenConfirm.deserialize(bytes),
      IbcTypes.ibcConnectionConnectionOpenInit =>
        IbcConnectionMsgConnectionOpenInit.deserialize(bytes),
      IbcTypes.ibcConnectionConnectionOpenTry =>
        IbcConnectionMsgConnectionOpenTry.deserialize(bytes),
      IbcTypes.ibcConnectionUpdateConnectionParams =>
        IbcConnectionMsgUpdateParams.deserialize(bytes),
      IbcTypes.ibcLightClientsWasmMigrateContract =>
        IbcLightClientsWasmMsgMigrateContract.deserialize(bytes),
      IbcTypes.ibcLightClientsWasmRemoveChecksum =>
        IbcLightClientsWasmMsgRemoveChecksum.deserialize(bytes),
      IbcTypes.ibcLightClientsWasmStoreCode =>
        IbcLightClientsWasmMsgStoreCode.deserialize(bytes),
      _ => null
    } as ServiceMessage?;
    print("service ${service.runtimeType}");
    if (service == null) return null;
    if (service is! T) {
      throw DartCosmosSdkPluginException("Invalid IBC Service.", details: {
        "excepted": "$T",
        "service": service.runtimeType.toString()
      });
    }
    return service;
  }
}
