class CCRConst {
  static const String chainRegisteryUri = "https://registry.ping.pub";
  static const String chainRegisteryUriTestnets =
      "https://registry.ping.pub/testnets";
}
