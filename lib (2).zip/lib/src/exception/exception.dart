import 'package:blockchain_utils/blockchain_utils.dart';

class DartCosmosSdkPluginException extends BlockchainUtilsException {
  const DartCosmosSdkPluginException(super.message, {super.details});
}
