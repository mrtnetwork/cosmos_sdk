import 'package:cosmos_sdk/src/models/ibc/types/types.dart';
import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

abstract class IbcService<T extends CosmosMessage> extends CosmosMessage
    with ServiceMessage<T> {
  const IbcService();
  @override
  IbcTypes get service;
}
