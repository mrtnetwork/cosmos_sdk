import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:cosmos_sdk/src/models/ibc/core/service.dart';
import 'package:cosmos_sdk/src/models/ibc/ibc_core_client_v1/messages/height.dart';

import 'package:cosmos_sdk/src/models/ibc/types/types.dart';
import 'package:cosmos_sdk/src/models/global_messages/service_empty_response.dart';
import 'package:cosmos_sdk/src/protobuf/protobuf.dart';
import 'package:cosmos_sdk/src/utils/quick.dart';

/// MsgChannelOpenConfirm defines a msg sent by a Relayer to Chain
/// B to acknowledge the change of channel state to OPEN on Chain A.
class MsgChannelOpenConfirm extends IbcService<EmptyServiceRequestResponse> {
  final String? portId;
  final String? channelId;
  final List<int>? proofAck;
  final IbcClientHeight proofHeight;
  final String? signer;
  MsgChannelOpenConfirm(
      {this.portId,
      this.channelId,
      List<int>? proofAck,
      required this.proofHeight,
      this.signer})
      : proofAck = BytesUtils.tryToBytes(proofAck, unmodifiable: true);
  factory MsgChannelOpenConfirm.deserialize(List<int> bytes) {
    final decode = CosmosProtocolBuffer.decode(bytes);
    return MsgChannelOpenConfirm(
        portId: decode.getField(1),
        channelId: decode.getField(2),
        proofAck: decode.getField(3),
        proofHeight: IbcClientHeight.deserialize(decode.getField(4)),
        signer: decode.getField(5));
  }
  factory MsgChannelOpenConfirm.fromJson(Map<String, dynamic> json) {
    return MsgChannelOpenConfirm(
        portId: json.as("port_id"),
        channelId: json.as("channel_id"),
        proofAck: json.asBytes("proof_ack"),
        proofHeight: IbcClientHeight.fromJson(json.asMap("proof_height")),
        signer: json.as("signer"));
  }

  @override
  List<int> get fieldIds => [1, 2, 3, 4, 5];

  @override
  IbcTypes get service => IbcTypes.channelOpenConfirm;

  @override
  Map<String, dynamic> toJson() {
    return {
      "port_id": portId,
      "channel_id": channelId,
      "proof_ack": BytesUtils.tryToHexString(proofAck),
      "proof_height": proofHeight.toJson(),
      "signer": signer
    };
  }

  @override
  TypeUrl get typeUrl => IbcTypes.msgChannelOpenConfirm;

  @override
  List get values => [portId, channelId, proofAck, proofHeight, signer];

  @override
  List<String?> get signers => [signer];

  @override
  EmptyServiceRequestResponse onResponse(List<int> bytes) {
    return EmptyServiceRequestResponse(IbcTypes.msgChannelOpenConfirmResponse);
  }
}
