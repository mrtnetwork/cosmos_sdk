import 'package:cosmos_sdk/src/models/networks/osmosis/osmosis_concentrated_liquidity_v1beta1/types/types.dart';
import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

abstract class OsmosisConcentratedLiquidityV1Beta1<T extends CosmosMessage>
    extends CosmosMessage with ServiceMessage<T> {
  const OsmosisConcentratedLiquidityV1Beta1();
  @override
  OsmosisConcentratedLiquidityV1beta1Types get service;
}
