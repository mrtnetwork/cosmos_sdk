import 'package:cosmos_sdk/src/models/networks/osmosis/osmosis_concentratedliquidity_poolmodel_concentrated_1beta1/types/types.dart';
import 'package:cosmos_sdk/src/protobuf/serialization/cosmos_serialization.dart';

abstract class OsmosisConcentratedliquidityPoolmodelConcentratedV1Beta1<
    T extends CosmosMessage> extends CosmosMessage with ServiceMessage<T> {
  const OsmosisConcentratedliquidityPoolmodelConcentratedV1Beta1();
  @override
  OsmosisConcentratedliquidityPoolmodelConcentratedV1beta1Types get service;
}
