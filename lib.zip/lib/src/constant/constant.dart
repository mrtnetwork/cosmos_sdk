class CosmosConstants {
  static final RegExp strDurationRegExp = RegExp(r'^(\d+)(?:\.(\d+))?s$');
}
